//
//  foodTableViewCell.swift
//  NIBMCafe
//
//  Created by Admin on 2021-04-27.
//

import UIKit

class foodTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgfood: UIImageView!
    
    
    @IBOutlet weak var lblDiscount: UILabel!
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var lblfoodDiscription: UILabel!
    @IBOutlet weak var lblprice: UILabel!
    
    @IBOutlet weak var lblfoodName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    func SetupView(foodItem : FoodItem){
       
        lblfoodName.text = foodItem.foodName
        lblfoodDiscription.text = foodItem.foodDiscription
        lblprice.text = "LKR \(foodItem.foodPrice)"
        imgfood.image = UIImage(named: foodItem.image)
        
        if foodItem.discount > 0{
            viewContainer.isHidden = false
            lblDiscount.text = "\(foodItem.discount)%"
            
        }else{
            viewContainer.isHidden = true
            lblDiscount.text = ""
        }
        
        
        
    }
    
}
