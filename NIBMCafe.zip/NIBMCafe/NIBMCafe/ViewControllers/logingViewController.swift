//
//  logingViewController.swift
//  NIBMCafe
//
//  Created by Admin on 2021-04-11.
//

import UIKit
import Firebase

class logingViewController: UIViewController {
    
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtpassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
   
    @IBAction func onLogingBtn(_ sender: UIButton) {
        
        if validateInput(){
            
            authenticateUser(email: txtemail.text!, password: txtpassword.text!)
            
        }else{
            print("input error found")
        }
        
    }
    
    func validateInput() -> Bool{
        
        guard let email = txtemail.text else {
            print("Email is null")
            return false
        }
        
        guard let password = txtpassword.text else {
            print("password is null")
            return false
        }
        
        if email.count < 5 {
            print("enter a valid Email")
            return false
        }
        if password.count < 5 {
            print("enter a valid email")
            return false
        }
        
        return true
    }
    
    func authenticateUser(email:String,password:String){
        
        Auth.auth().signIn(withEmail: email, password: password){
            authResult, error in
            
            if let error = error{
                print(error.localizedDescription)
                return
            }
            if let result = authResult{
                print("User email :\(result.user.email ?? "No found")")
            }
         
      
        
        }
        
    }
  
    

}
