//
//  SessionManager.swift
//  NIBMCafe
//
//  Created by Admin on 2021-04-12.
//

import Foundation

class SessionManager{
    
    func getLogingStates() -> Bool{
       return UserDefaults.standard.bool(forKey: "USER_LOGGED")
       
        
    }
    
    func clearUserLoging(){
        UserDefaults.standard.setValue(false, forKey: "USER_LOGGED")
    }
    
    func saveUserLoging(){
        UserDefaults.standard.setValue(true, forKey: "USER_LOGGED")
    }
    
}
